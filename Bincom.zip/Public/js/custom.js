        $(document).ready(function() {
            $("#nav-button").click(function() {
                $("#social-icons").toggle();
            });
            $("#nav-button").click(function() {
                $("#social").toggle();
            });
        });


        $(document).ready(function() {
            $("#myModal").modal('show');
        });